var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <Map Name=\"XXXXXXXX\" Link=\"North America/San Diego.htm\" ResolvedId=\"1000\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
